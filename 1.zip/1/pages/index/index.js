//index.js
//获取应用实例
const app = getApp()
const BackgroundAudioManager = wx.getBackgroundAudioManager()

BackgroundAudioManager.title = "Yellow(青涩)"
BackgroundAudioManager.epname = "Yellow"
BackgroundAudioManager.singer = "Coldplay"
BackgroundAudioManager.src = 'http://sinacloud.net/huangpinyuan/Yellow%28asoustic%29.m4a?KID=sina,2v1h20zDUHt8eJnLWZSc&Expires=1545414609&ssig=grHet4acQc'

Page({
  data: {
    motto: '一梦黄粱',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  a:function() {
    wx.redirectTo({
      url: '../A/1',
    })
  },
  bindPlaySong: function () {
    console.log('播放/暂停音乐...');
    console.log(this.data.playStatus);
    if (this.data.playStatus === true) {
      wx.playBackgroundAudio();
      this.setData({
        playStatus: false
      });
    } else {
      wx.pauseBackgroundAudio();
      this.setData({
        playStatus: true
      });
    }
  },
  
})
